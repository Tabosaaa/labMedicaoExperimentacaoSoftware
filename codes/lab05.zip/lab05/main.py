from github_graphql_api_test import graphql
from github_rest_api_test import rest

graphql()
rest()